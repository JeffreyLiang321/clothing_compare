async function getAppOrigin() {
    const { appOrigin } = await chrome.storage.sync.get(["appOrigin"]);
    return (appOrigin && String(appOrigin).trim()) || "";
}

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab?.id) return;

  const appOrigin = await getAppOrigin();
  if (!appOrigin) {
    // Not configured yet — open the options page so the user can set the app URL
    chrome.runtime.openOptionsPage();
    return;
  }

  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      const url = window.location.href;

      const ogTitle =
        document.querySelector('meta[property="og:title"]')?.content ||
        document.querySelector('meta[name="twitter:title"]')?.content ||
        "";
      const name = (ogTitle || document.title || "").trim();

      // Store from hostname
      const host = window.location.hostname.replace(/^www\./, "");
      const store = host.split(".")[0] || host;

      // Best-effort price
      const metaPrice =
        document.querySelector('meta[property="product:price:amount"]')?.content ||
        document.querySelector('meta[property="og:price:amount"]')?.content ||
        "";

      let price = "";
      if (metaPrice) {
        price = String(metaPrice).trim();
      } else {
        const text = document.body?.innerText || "";
        const m = text.match(/(\$|US\$|HK\$|£|€)\s?\d{1,5}(?:[.,]\d{2})?/);
        if (m?.[0]) price = m[0];
      }

      const image =
      document.querySelector('meta[property="og:image"]')?.content ||
      document.querySelector('meta[name="twitter:image"]')?.content ||
      "";

      return { url, name, store, price, image };
    }
  });

  const data = result || {};
  const params = new URLSearchParams();

  if (data.url) params.set("url", data.url);
  if (data.name) params.set("name", data.name);

  if (data.store) {
    const s = data.store;
    params.set("store", s.charAt(0).toUpperCase() + s.slice(1));
  }

  if (data.price) {
    const numeric = String(data.price).replace(/[^0-9.]/g, "");
    if (numeric) params.set("price", numeric);
  }

  if (data.image) params.set("image_url", data.image);

  const addUrl = `${appOrigin.replace(/\/$/, "")}/add?${params.toString()}`;
  chrome.tabs.create({ url: addUrl });
});
